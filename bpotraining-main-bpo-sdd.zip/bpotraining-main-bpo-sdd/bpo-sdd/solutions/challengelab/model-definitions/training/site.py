from plansdk.apis.plan import Plan
from .util import failure, success
from .port import ValidateActivate as PortValidateActivate
import logging

log = logging.getLogger(__name__)

class ValidateActivate(Plan):
    """
    Verify that another Site does not exists with the same siteId or using the same Port
    Verify that another Site does not exists with the same portName and deviceName combination
    Verify that the managed device and port resources exist
    """
    def run(self):
        log.info(f"ValidateActivate: Input params: {self.params}")
        inputs = self.params['inputs']
        resource = inputs.get('resource')
        properties = resource.get('properties')

        sites = self.bpo.resources.get_by_type("training.resourceTypes.Site")
        for site in sites:
            if site['properties']['siteId'] == properties['siteId']:
                return failure(f"Site with siteId ({properties['siteId']}) already exists")
            elif (site['properties']['deviceName'] == properties['deviceName']) and (site['properties']['portName'] == properties['portName']):
                return failure(f"Site with the same portName and deviceName combination already exists")

        port_validation = PortValidateActivate.run(self)
        if port_validation['state'] == "failed":
            return port_validation

        log.info("ValidateActivate: DONE")
        return success("Validation successful")

class Activate(Plan):
    """
    Creates Site resource into market
    Creates Port resource into market
    """
    def run(self):
        log.info(f"Activate: Input params: {self.params}")

        resource_id = self.params['resourceId']
        resource = self.bpo.resources.get(resource_id)

        log.info(f"Activate: resourceId {resource_id}")
        log.info(f"Resource: {resource}")

        port = self.create_port(resource)
        log.info(f"Create Port resource: {port}")

        log.info("Activate: DONE")
        return {}

    def create_port(self, resource):
        properties = resource['properties']
        port_product = self.bpo.market.get_products_by_resource_type('training.resourceTypes.Port')[0]

        # Create the resource
        port_resource = self.bpo.market.post("/resources", {
            'productId': port_product['id'],
            'label': f"{resource['label']}.Port",
            'properties': {'deviceName': properties["deviceName"],
                           'portName': properties["portName"],
                            'portSpeed': properties["portSpeed"]},
            "desiredOrchState": "requested",
            "orchState": "requested"
        })

        # Patch the desired operational state
        self.bpo.market.patch(f"/resources/{port_resource['id']}", {
            "desiredOrchState": "active"
        })
        
        # Create a relationship between the Site and the Port
        self.bpo.market.post("/relationships", {
            "relationshipTypeId": "tosca.relationshipTypes.DependsOn",
            "sourceId": resource['id'],
            "targetId": port_resource['id'],
            "requirementName": "composed",
            "capabilityName": "composable"            
        })

        return port_resource

class Terminate(Plan):
    """
    Remove Site resource from market
    Remove dependent Port resources from market
    """
    def run(self):
        log.info(f"Terminate: Input params: {self.params}")

        resource_id = self.params['resourceId']
        resource = self.bpo.resources.get(resource_id)

        log.info(f"Terminate: resourceId {resource_id}")
        log.info(f"Resource: {resource}")

        self.delete_port(resource_id)
        log.info(f"Deleting Port dependencies for Site {resource['label']}")

        dependencies = self.bpo.resources.get_dependencies(resource_id)
        if dependencies:
            raise Exception(f"Site has dependencies ({dependencies})")

        log.info(f"Terminate: DONE")

    def delete_port(self, resource_id):
        dependencies = self.bpo.resources.get_dependencies(resource_id)
        self.bpo.resources.delete_dependencies(
                            self.params['resourceId'],
                            'training.resourceTypes.Port',
                            dependencies)
