def failure(message, status_code=400):
    """
    Validation report for failure
    :param message:
    :param status_code:
    :return:
    """
    return {
        "state": "failed",
        "results": [
            {
                "status": status_code,
                "detail": message
            }
        ]
    }

def success(message, status_code=200):
    """
    Validation report for failure
    :param message:
    :param status_code:
    :return:
    """
    return {
        "state": "passed",
        "results": [
            {
                "status": status_code,
                "detail": message
            }
        ]
    }
