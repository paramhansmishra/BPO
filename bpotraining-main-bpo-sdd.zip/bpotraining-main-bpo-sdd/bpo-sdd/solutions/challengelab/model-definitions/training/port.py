from plansdk.apis.plan import Plan
from plansdk.apis.bpo import ExactTypeId
from .util import failure, success
import logging

log = logging.getLogger(__name__)

class PortUtils():
    def get_managed_port_resource(self, port_name, device_name, port_speed):
        if port_speed == '1Gbps':
            managed_port_resource_type = ExactTypeId("radevsim.resourceTypes.GigabitEthernet")
        elif port_speed == '10Gbps':
            managed_port_resource_type = ExactTypeId("radevsim.resourceTypes.TenGigabitEthernet")
        elif port_speed == '100Mbps':
            managed_port_resource_type = ExactTypeId("radevsim.resourceTypes.HundredMegabitEthernet")
        else:
            return failure(f"{port_speed} is not a valid choice for Port Speed! Supported speeds are: 1Gbps, 10Gbps, 100Mbps")

        managed_device_resource = PortUtils.get_managed_device_resource(self, device_name)

        try:
            managed_device_all_ports = self.bpo.resources.get_dependents_with_filters(managed_device_resource['id'], managed_port_resource_type)
            managed_port_resource = [port for port in managed_device_all_ports if port['label'] == port_name][0]
        except:
            raise Exception(f"Managed port {port_name} does not exist!")
        return managed_port_resource

    def get_managed_device_resource(self, device_name):
        managed_devices = self.bpo.resources.get_with_filters(
            ExactTypeId("radevsim.resourceTypes.Device")
        )
        try:
            managed_device_resource = [device for device in managed_devices if device['label'] == device_name][0]
        except:
            raise Exception(f"Managed device {device_name} does not exist!")
        return managed_device_resource

class ValidateActivate(Plan):
    """
    Validate that the same port on the same device does not exist yet
    Validate that a managed device exists
    Validate that a managed port exists
    """
    def run(self):
        log.info(f"ValidateActivate: Input params: {self.params}")
        inputs = self.params['inputs']
        resource = inputs.get('resource')
        properties = resource.get('properties')

        ports = self.bpo.resources.get_by_type("training.resourceTypes.Port")
        for port in ports:
            if (port['properties']['deviceName'] == properties['deviceName']) and (port['properties']['portName'] == properties['portName']):
                return failure(f"Port with number ({properties['portName']}) already exists on device {properties['deviceName']}")

        # Verify that a managed device exists
        try:
            managed_device_resource = PortUtils.get_managed_device_resource(self, properties['deviceName'])
            log.info(f"Found managed device resource {managed_device_resource}")
        except:
            return failure(f"Managed device {properties['deviceName']} does not exist!")

        # Verify that a managed port with chosen speed and label exist on managed device
        try:
            managed_port_resource = PortUtils.get_managed_port_resource(self, properties['portName'], properties['deviceName'], properties['portSpeed'])
            log.info(f"Found managed port resource {managed_port_resource}")
        except:
            return failure(f"Unable to find managed port resource that matches device/port/speed combination {properties['deviceName']} ({properties['portName']}) {properties['portSpeed']}")

        log.info("ValidateActivate: DONE")
        return success("Validation successful")

class Activate(Plan):
    """
    Create Port resource into market
    Create relationship with managed port resource
    """
    def run(self):
        log.info(f"Activate: Input params: {self.params}")

        resource_id = self.params['resourceId']
        resource = self.bpo.resources.get(resource_id)

        log.info(f"Activate: resourceId {resource_id}")
        log.info(f"Resource: {resource}")

        # Create relationship with managed resource
        properties = resource['properties']
        managed_port_resource = PortUtils.get_managed_port_resource(self, properties['portName'], properties['deviceName'], properties['portSpeed'])
        self.bpo.relationships.add_relationship(resource['id'], managed_port_resource['id'])

        log.info("Activate: DONE")
        return {}

class Terminate(Plan):
    """
    Delete Port resource from market
    Delete relationship with managed port resource
    """
    def run(self):
        log.info(f"Terminate: Input params: {self.params}")

        resource_id = self.params['resourceId']
        resource = self.bpo.resources.get(resource_id)

        log.info(f"Terminate: resourceId {resource_id}")
        log.info(f"Resource: {resource}")

        self.bpo.relationships.delete_source_relationships(self.params['resourceId'])

        dependencies = self.bpo.resources.get_dependencies(resource_id)
        if dependencies:
            raise Exception(f"Port has dependencies ({dependencies})")

        log.info(f"Terminate: DONE")
        return {}


