from plansdk.apis.plan import Plan
from .util import failure, success
import logging

log = logging.getLogger(__name__)

class ValidateActivate(Plan):
    """
    Verify that another customer does not exists with the same customerName or customerAccountNumber
    """
    def run(self):
        log.info(f"ValidateActivate: Input params: {self.params}")
        inputs = self.params['inputs']
        resource = inputs.get('resource')
        properties = resource.get('properties')

        customers = self.bpo.resources.get_by_type("training.resourceTypes.Customer")
        for customer in customers:
            if customer['properties']['customerName'] == properties['customerName']:
                return failure(f"Customer with customerName ({properties['customerName']}) already exists")
            elif customer['properties']['customerAccountNumber'] == properties['customerAccountNumber']:
                return failure(f"Customer with customerAccountNumber ({properties['customerAccountNumber']}) already exists")

        log.info("ValidateActivate: DONE")
        return success("Validation successful")

class Activate(Plan):
    """
    Creates Customer resource into market
    """
    def run(self):
        log.info(f"Activate: Input params: {self.params}")

        resource_id = self.params['resourceId']
        resource = self.bpo.resources.get(resource_id)

        log.info(f"Activate: resourceId {resource_id}")
        log.info(f"Resource: {resource}")

        log.info("Activate: DONE")
        return {}

class Terminate(Plan):
    """
    Remove Customer resource from market
    """
    def run(self):
        log.info(f"Terminate: Input params: {self.params}")

        resource_id = self.params['resourceId']
        resource = self.bpo.resources.get(resource_id)

        log.info(f"Terminate: resourceId {resource_id}")
        log.info(f"Resource: {resource}")

        dependencies = self.bpo.resources.get_dependencies(resource_id)
        if dependencies:
            raise Exception(f"Customer has dependencies ({dependencies})")

        log.info(f"Terminate: DONE")
        return {}







