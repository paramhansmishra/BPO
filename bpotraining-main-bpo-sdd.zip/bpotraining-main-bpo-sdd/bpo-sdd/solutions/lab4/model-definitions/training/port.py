from plansdk.apis.plan import Plan
from .util import failure, success
import logging

log = logging.getLogger(__name__)

class ValidateActivate(Plan):
    """
    Validate that the same port on the same device does not exist yet
    """
    def run(self):
        log.info(f"ValidateActivate: Input params: {self.params}")
        inputs = self.params['inputs']
        resource = inputs.get('resource')
        properties = resource.get('properties')

        ports = self.bpo.resources.get_by_type("training.resourceTypes.Port")
        for port in ports:
            if (port['properties']['deviceName'] == properties['deviceName']) and (port['properties']['portName'] == properties['portName']):
                return failure(f"Port with number ({properties['portName']}) already exists on device {properties['deviceName']}")

        log.info("ValidateActivate: DONE")
        return success("Validation successful")

class Activate(Plan):
    """
    Create Port resource into market
    """
    def run(self):
        log.info(f"Activate: Input params: {self.params}")

        resource_id = self.params['resourceId']
        resource = self.bpo.resources.get(resource_id)

        log.info(f"Activate: resourceId {resource_id}")
        log.info(f"Resource: {resource}")

        log.info("Activate: DONE")
        return {}

class Terminate(Plan):
    """
    Delete Port resource from market
    """
    def run(self):
        log.info(f"Terminate: Input params: {self.params}")

        resource_id = self.params['resourceId']
        resource = self.bpo.resources.get(resource_id)

        log.info(f"Terminate: resourceId {resource_id}")
        log.info(f"Resource: {resource}")

        dependencies = self.bpo.resources.get_dependencies(resource_id)
        if dependencies:
            raise Exception(f"Port has dependencies ({dependencies})")

        log.info(f"Terminate: DONE")
        return {}


