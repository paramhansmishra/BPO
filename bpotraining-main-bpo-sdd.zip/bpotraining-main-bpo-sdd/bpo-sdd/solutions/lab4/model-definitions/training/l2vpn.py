from plansdk.apis.plan import Plan
from .util import failure, success
import logging

log = logging.getLogger(__name__)

POOL_NAME = "Training Pool"
POOL_RESOURCE_TYPE = "tosca.resourceTypes.NumberPool"
POOL_NUMBER_RESOURCE_TYPE = "tosca.resourceTypes.PooledNumber"

class ValidateActivate(Plan):
    """
    Verify that BandwidthProfile resource exists
    Verify that Customer resource exists
    Verify that Site resource exist
    Verify that a L2VPN resource does not exist with the same label
    """
    def run(self):
        log.info(f"ValidateActivate: Input params: {self.params}")
        inputs = self.params['inputs']
        resource = inputs['resource']
        properties = resource['properties']

        try:
            customer = self.bpo.resources.get_one_by_filters(
                resource_type="training.resourceTypes.Customer",
                q_params={"label": properties['customerLabel']}
            )
        except:
            return failure(f"Customer with label ({properties['customerLabel']}) does not exist")

        try:
            bp = self.bpo.resources.get_one_by_filters(
                resource_type="training.resourceTypes.BandwidthProfile",
                q_params={"label": properties['bandwidthProfile']}
            )
        except:
            return failure(f"BandwidthProfile with label ({properties['bandwidthProfile']}) does not exist")

        try:
            site = self.bpo.resources.get_one_by_filters(
                resource_type="training.resourceTypes.Site",
                q_params={"label": properties['siteLabel']}
            )
        except:
            return failure(f"Site with label ({properties['siteLabel']}) does not exist")

        log.info("ValidateActivate: DONE")
        return success("Validation successful")

class Activate(Plan):
    """
    Create L2VPN resource into market
    Create relationship with Customer, Site, and Bandwidth Profile resource
    """
    def run(self):
        log.info(f"Activate: Input params: {self.params}")

        resource_id = self.params['resourceId']
        resource = self.bpo.resources.get(resource_id)

        log.info(f"Activate: resourceId {resource_id}")
        log.info(f"Resource: {resource}")

        properties = resource['properties']
        self.assign_customer(properties)
        log.info(f"Assign Customer resource: {properties['customerLabel']}")

        self.assign_site(properties)
        log.info(f"Assign Site resource: {properties['siteLabel']}")

        self.assign_bandwidthprofile(properties)
        log.info(f"Assign Bandwidth Profile resource: {properties['bandwidthProfile']}")

        self.create_vlan_pool()
        self.allocate_vlan(resource)

        log.info("Activate: DONE")
        return {}

    def assign_customer(self, properties):
        resource_id = self.params['resourceId']
        customer = self.bpo.resources.get_one_by_filters(
                resource_type="training.resourceTypes.Customer",
                q_params={"label": properties['customerLabel']}
        )
        self.bpo.relationships.add_relationship(resource_id, customer['id'])

    def assign_site(self, properties):
        resource_id = self.params['resourceId']
        site = self.bpo.resources.get_one_by_filters(
                resource_type="training.resourceTypes.Site",
                q_params={"label": properties['siteLabel']}
        )
        self.bpo.relationships.add_relationship(resource_id, site['id'])

    def assign_bandwidthprofile(self, properties):
        resource_id = self.params['resourceId']
        site = self.bpo.resources.get_one_by_filters(
                resource_type="training.resourceTypes.BandwidthProfile",
                q_params={"label": properties['bandwidthProfile']}
        )
        self.bpo.relationships.add_relationship(resource_id, site['id'])

    def create_vlan_pool(self):
        # Try to find the "tosca.resourceTypes.NumberPool" resource
        # If none are found, create it
        try:
            pool = self.bpo.resources.get_one_by_filters(
                resource_type = POOL_RESOURCE_TYPE,
                q_params = { "label": POOL_NAME }
            )
            log.info(f"Found VLAN pool {POOL_NAME}")
        except:
            log.info(f"VLAN pool {POOL_NAME} doesn't exist. Creating...")
            vlan_pool_id = self.bpo.market.get_products_by_resource_type(POOL_RESOURCE_TYPE)[0]['id']

            # Training VLAN pool created with no parent - it is global
            pool = self.bpo.resources.create(None, {
                'productId': vlan_pool_id,
                'label': POOL_NAME,
                'properties': { "lowest":  1,
                                "highest": 4096 }
            })
        return pool

    def allocate_vlan(self, resource):
        pool_number_product_id = None

        # First, read the ID from product based on "tosca.resourceTypes.PooledNumber"
        try:
            pool_number_product_id = self.bpo.products.get_by_domain_and_type("built-in", POOL_NUMBER_RESOURCE_TYPE)[0]['id']
            log.info(f"Found VLAN pool number product with ID {pool_number_product_id}")
        except:
            raise Exception(f"VLAN pool number product with ID {pool_number_product_id} doesn't exist")

        vlan_id = resource['properties'].get('vlanId')
        label = resource['label']

        # If vlanId has been entered use that when creating the VLAN resource, else use the allocated number from PooledNumber
        pool_number_product_id = self.bpo.products.get_by_domain_and_type("built-in", POOL_NUMBER_RESOURCE_TYPE)[0]['id']
        if vlan_id:
            allocated_number = self.bpo.resources.create(resource['id'], {
                'productId': pool_number_product_id,
                'label': f"{label}.VLAN",
                'properties': { "requestedValue": vlan_id }
            })
        else:
            allocated_number = self.bpo.resources.create(resource['id'], {
                'productId': pool_number_product_id,
                'label': f"{label}.VLAN"
            })
        log.info(f"Successfully allocated VLAN pool number - {allocated_number}")

class Terminate(Plan):
    """
    Delete L2VPN resource from market
    Delete Customer, Site, and Bandwidthprofile relationships
    """
    def run(self):
        log.info(f"Terminate: Input params: {self.params}")

        resource_id = self.params['resourceId']
        resource = self.bpo.resources.get(resource_id)

        log.info(f"Terminate: resourceId {resource_id}")
        log.info(f"Resource: {resource}")

        label = resource['label']
        try:
            vlan_num_res = self.bpo.resources.get_one_by_filters(
                    resource_type=POOL_NUMBER_RESOURCE_TYPE,
                    q_params={"label": f"{label}.VLAN"}
            )
            self.bpo.resources.delete(vlan_num_res['id'])
            self.bpo.resources.await_termination(vlan_num_res['id'], f"{label}.VLAN", False)
            log.info(f"VLAN for {label} released")
        except:
            log.info(f"VLAN for {label} not found")

        self.delete_l2vpn_relationships(resource_id)
        log.info(f"Deleting Customer, Site and BandwidthProfile relationships")

        dependencies = self.bpo.resources.get_dependencies(resource_id)
        if dependencies:
            raise Exception(f"Site has dependencies ({dependencies})")

        log.info(f"Terminate: DONE")
        return {}

    def delete_l2vpn_relationships(self, resource_id):
        self.bpo.relationships.delete_source_relationships(resource_id)

class Update(Plan):
    """
    Updates the VLAN parameter
    """
    def run(self):
        log.info(f"Update: Input params: {self.params}")

        resource_id = self.params['resourceId']
        resource = self.bpo.resources.get(resource_id)

        log.info(f"Update: resourceId {resource_id}")
        log.info(f"Update: {resource}")

        label = resource['label']
        vlan_num_res = self.bpo.resources.get_one_by_filters(
                resource_type=POOL_NUMBER_RESOURCE_TYPE,
                q_params={"label": f"{label}.VLAN"}
        )

        self.bpo.relationships.delete_relationships(vlan_num_res['id'])
        self.bpo.resources.delete(vlan_num_res['id'])
        log.info(f"VLAN for {label} released")

        Activate.allocate_vlan(self, resource)

        log.info(f"Update: DONE")
        return {}

class ChangePort(Plan):
    """
    Changes the Port and Device attached to selected Site in L2VPN resource
    """
    def run(self):
        log.info(f"ChangePort: Input params: {self.params}")

        resource_id = self.params['resourceId']
        resource = self.bpo.resources.get(resource_id)

        log.info(f"ChangePort: resourceId {resource_id}")
        log.info(f"ChangePort: {resource}")

        operation = self.bpo.resources.get_operation(resource_id, self.params['operationId'])
        inputs = operation['inputs']

        log.info(f"ChangePort: inputs {inputs}")
        site_label = inputs['siteLabel']

        # Verify that the Site exists
        try:
            site_res = self.bpo.resources.get_one_by_filters(
                    resource_type="training.resourceTypes.Site",
                    q_params={"label": f"{site_label}"}
            )
            log.info(f"Site resource for {site_label} found.")
        except:
            raise Exception(f"Site resource for {site_label} not found.")

        # Find the Port resource attached to this Site
        try:
            port_res = self.bpo.resources.get_dependency_by_type(site_res['id'], "training.resourceTypes.Port")
            log.info(f"Port resource for {site_label} found - {port_res}")
        except:
            raise Exception(f"Port resource for {site_label} not found!")

        # Patch the Port resource
        self.bpo.resources.patch(port_res['id'], {
            "properties": {
                "portName": inputs['portName'],
                "deviceName": inputs['deviceName'],
                "portSpeed": inputs['portSpeed']
            }
        })
        log.info(f"Port resource for {site_label} patched.")

        # Patch the Site resource
        self.bpo.resources.patch(site_res['id'], {
            "properties": {
                "portName": inputs['portName'],
                "deviceName": inputs['deviceName'],
                "portSpeed": inputs['portSpeed']
            }
        })
        log.info(f"Site resource for {site_label} patched.")

        log.info(f"ChangePort: DONE")
