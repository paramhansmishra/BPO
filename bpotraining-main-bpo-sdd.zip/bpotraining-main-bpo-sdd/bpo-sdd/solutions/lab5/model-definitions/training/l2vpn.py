from plansdk.apis.plan import Plan
from plansdk.apis.bpo import ExactTypeId, QQuery
from .port import PortUtils
from .util import failure, success
import logging

log = logging.getLogger(__name__)

POOL_NAME = "Training Pool"
POOL_RESOURCE_TYPE = "tosca.resourceTypes.NumberPool"
POOL_NUMBER_RESOURCE_TYPE = "tosca.resourceTypes.PooledNumber"

class ValidateActivate(Plan):
    """
    Verify that BandwidthProfile resource exists
    Verify that Customer resource exists
    Verify that Site resource exist
    Verify that a L2VPN resource does not exist with the same label
    """
    def run(self):
        log.info(f"ValidateActivate: Input params: {self.params}")
        inputs = self.params['inputs']
        resource = inputs['resource']
        properties = resource['properties']

        # Verify that Customer resource exists
        try:
            customer = self.bpo.resources.get_one_by_filters(
                resource_type="training.resourceTypes.Customer",
                q_params={"label": properties['customerLabel']}
            )
        except:
            return failure(f"Customer with label ({properties['customerLabel']}) does not exist")

        # Verify that BandwidthProfile resource exists
        try:
            bp = self.bpo.resources.get_one_by_filters(
                resource_type="training.resourceTypes.BandwidthProfile",
                q_params={"label": properties['bandwidthProfile']}
            )
        except:
            return failure(f"BandwidthProfile with label ({properties['bandwidthProfile']}) does not exist")

        # Verify that Site resource exists
        try:
            site = self.bpo.resources.get_one_by_filters(
                resource_type="training.resourceTypes.Site",
                q_params={"label": properties['siteLabel']}
            )
        except:
            return failure(f"Site with label ({properties['siteLabel']}) does not exist")

        log.info("ValidateActivate: DONE")
        return success("Validation successful")

class Activate(Plan):
    """
    Create L2VPN resource into market
    Create relationship with Customer, Site, and Bandwidth Profile resource
    Allocate VLAN
    Create a managed VLAN resource
    Create a managed logical port resource
    Create a managed Policy Map resource
    """
    def run(self):
        log.info(f"Activate: Input params: {self.params}")

        resource_id = self.params['resourceId']
        resource = self.bpo.resources.get(resource_id)

        log.info(f"Activate: resourceId {resource_id}")
        log.info(f"Resource: {resource}")

        properties = resource['properties']
        self.assign_customer(properties)
        log.info(f"Assign Customer resource: {properties['customerLabel']}")

        self.assign_site(properties)
        log.info(f"Assign Site resource: {properties['siteLabel']}")

        self.assign_bandwidthprofile(properties)
        log.info(f"Assign Bandwidth Profile resource: {properties['bandwidthProfile']}")

        self.create_vlan_pool()
        allocated_vlan = self.allocate_vlan(resource)

        self.create_managed_vlan_resource(resource, allocated_vlan)
        self.create_managed_policy_map(resource)
        self.create_managed_logical_port(resource, allocated_vlan)

        log.info("Activate: DONE")
        return {}

    def assign_customer(self, properties):
        resource_id = self.params['resourceId']
        customer = self.bpo.resources.get_one_by_filters(
                resource_type="training.resourceTypes.Customer",
                q_params={"label": properties['customerLabel']}
        )
        self.bpo.relationships.add_relationship(resource_id, customer['id'])

    def assign_site(self, properties):
        resource_id = self.params['resourceId']
        site = self.bpo.resources.get_one_by_filters(
                resource_type="training.resourceTypes.Site",
                q_params={"label": properties['siteLabel']}
        )
        self.bpo.relationships.add_relationship(resource_id, site['id'])

    def assign_bandwidthprofile(self, properties):
        resource_id = self.params['resourceId']
        site = self.bpo.resources.get_one_by_filters(
                resource_type="training.resourceTypes.BandwidthProfile",
                q_params={"label": properties['bandwidthProfile']}
        )
        self.bpo.relationships.add_relationship(resource_id, site['id'])

    def create_vlan_pool(self):
        # Try to find the "tosca.resourceTypes.NumberPool" resource
        # If none are found, create it
        try:
            pool = self.bpo.resources.get_one_by_filters(
                resource_type = POOL_RESOURCE_TYPE,
                q_params = { "label": POOL_NAME }
            )
            log.info(f"Found VLAN pool {POOL_NAME}")
        except:
            log.info(f"VLAN pool {POOL_NAME} doesn't exist. Creating...")
            vlan_pool_id = self.bpo.market.get_products_by_resource_type(POOL_RESOURCE_TYPE)[0]['id']

            # Training VLAN pool created with no parent - it is global
            pool = self.bpo.resources.create(None, {
                'productId': vlan_pool_id,
                'label': POOL_NAME,
                'properties': { "lowest":  2,
                                "highest": 4096 }
            })
        return pool

    def allocate_vlan(self, resource):
        pool_number_product_id = None

        # First, read the ID from product based on "tosca.resourceTypes.PooledNumber"
        try:
            pool_number_product_id = self.bpo.products.get_by_domain_and_type("built-in", POOL_NUMBER_RESOURCE_TYPE)[0]['id']
            log.info(f"Found VLAN pool number product with ID {pool_number_product_id}")
        except:
            raise Exception(f"VLAN pool number product with ID {pool_number_product_id} doesn't exist")

        vlan_id = resource['properties'].get('vlanId')
        label = resource['label']

        # If vlanId has been entered use that when creating the VLAN resource,
        # else use the allocated number from PooledNumber
        pool_number_product_id = self.bpo.products.get_by_domain_and_type("built-in", POOL_NUMBER_RESOURCE_TYPE)[0]['id']
        if vlan_id:
            allocated_number = self.bpo.resources.create(resource['id'], {
                'productId': pool_number_product_id,
                'label': f"{label}.VLAN",
                'properties': { "requestedValue": vlan_id }
            })
        else:
            allocated_number = self.bpo.resources.create(resource['id'], {
                'productId': pool_number_product_id,
                'label': f"{label}.VLAN"
            })
        log.info(f"Successfully allocated VLAN pool number - {allocated_number[0]['properties']['allocatedValue']}")
        return allocated_number[0]['properties']['allocatedValue']

    def create_managed_vlan_resource(self, resource, allocated_vlan):
        properties = resource['properties']

        # Read the L2VPN Port resource
        port_resource = self.bpo.resources.get_one_with_filters(
            ExactTypeId("training.resourceTypes.Port"),
            QQuery("label", f"{properties['siteLabel']}.Port")
        )

        # Read the L2VPN Port Managed Device resource
        device_name = port_resource["properties"]["deviceName"]
        managed_device_resource = PortUtils.get_managed_device_resource(self, device_name)

        # Create a Managed VLAN resource
        managed_vlan_product = self.bpo.market.get_products_by_resource_type('radevsim.resourceTypes.Vlan')[0]['id']
        try:
            managed_vlan = self.bpo.resources.create(managed_device_resource["id"], {
                'productId': managed_vlan_product,
                'label': f"{device_name}.{resource['label']}.VLAN",
                'properties': {
                    "id":  allocated_vlan,
                    "name": f"{device_name}.{resource['label']}.VLAN",
                    "device": managed_device_resource["id"]
                }
            })
        except Exception as e:
            raise Exception(f"Failed to create VLAN with ID {allocated_vlan}. Make sure that it is available on device: {e}")
        self.bpo.relationships.add_relationship(resource['id'], managed_vlan[0]['id'])

    def create_managed_policy_map(self, resource):
        properties = resource['properties']

        # Read the L2VPN BandwidthProfile resource
        bwp_resource = self.bpo.resources.get_one_with_filters(
            ExactTypeId("training.resourceTypes.BandwidthProfile"),
            QQuery("label", properties['bandwidthProfile'])
        )

        # Read the L2VPN Site resource
        site_resource = self.bpo.resources.get_one_with_filters(
            ExactTypeId("training.resourceTypes.Site"),
            QQuery("label", properties['siteLabel'])
        )

        # Read the L2VPN Site Managed Device resource
        site_device = site_resource["properties"]["deviceName"]
        managed_device_resource = PortUtils.get_managed_device_resource(self, site_device)

        # Create a Managed Policy Map resource
        managed_policy_map_product = self.bpo.market.get_products_by_resource_type('radevsim.resourceTypes.PolicyMap')[0]['id']
        managed_policy_map = self.bpo.resources.create(managed_device_resource["id"], {
            'productId': managed_policy_map_product,
            'label': f"{site_device}.{resource['label']}.PolicyMap",
            'properties': {
                "name": f"{site_device}.{resource['label']}.PolicyMap",
                "device": managed_device_resource["id"],
                "police": {
                    "bc": bwp_resource['properties']['cbs'],
                    "be": bwp_resource['properties']['ebs'],
                    "cir": bwp_resource['properties']['cir'],
                    "pir": bwp_resource['properties']['eir']
                },
                "class": [{
                    "name": f"{resource['label']}-policy-class"
                }]
            }
        })
        self.bpo.relationships.add_relationship(resource['id'], managed_policy_map[0]['id'])

    def create_managed_logical_port(self, resource, allocated_vlan):

        properties = resource['properties']

        # Read the L2VPN Port resource
        port_resource = self.bpo.resources.get_one_with_filters(
            ExactTypeId("training.resourceTypes.Port"),
            QQuery("label", f"{properties['siteLabel']}.Port")
        )

        # Read the L2VPN Port Managed Device and port resource
        device_name = port_resource["properties"]["deviceName"]
        managed_device_resource = PortUtils.get_managed_device_resource(self, device_name)
        managed_port_resource = PortUtils.get_managed_port_resource(self, port_resource['properties']['portName'], port_resource['properties']['deviceName'], port_resource['properties']['portSpeed'])

        # Create managed logical port resource - <port>.<vlan>
        logical_port_product_id = managed_port_resource['productId']
        managed_logical_port_resource = self.bpo.resources.create(
            managed_port_resource['id'], {
            'productId': logical_port_product_id,
            'label': f"{managed_port_resource['label']}.{allocated_vlan}",
            'properties': {
                "name":  f"{managed_port_resource['label']}.{allocated_vlan}",
                "device": managed_device_resource['id'],
                "encapsulation": {
                    "dot1Q": {
                        "vlan-id": allocated_vlan
                    }
                }
            }
        })
        self.bpo.relationships.add_relationship(port_resource['id'], managed_logical_port_resource[0]['id'])

class Terminate(Plan):
    """
    Delete L2VPN resource from market
    Delete Customer, Site, and Bandwidthprofile relationships
    Delete managed VLAN resource
    Delete managed logical port resource
    Delete managed Policy Map resource
    """
    def run(self):
        log.info(f"Terminate: Input params: {self.params}")

        resource_id = self.params['resourceId']
        resource = self.bpo.resources.get(resource_id)

        log.info(f"Terminate: resourceId {resource_id}")
        log.info(f"Resource: {resource}")

        label = resource['label']
        try:
            vlan_num_res = self.bpo.resources.get_one_by_filters(
                    resource_type=POOL_NUMBER_RESOURCE_TYPE,
                    q_params={"label": f"{label}.VLAN"}
            )
            self.bpo.resources.delete(vlan_num_res['id'])
            self.bpo.resources.await_termination(vlan_num_res['id'], f"{label}.VLAN", False)
            log.info(f"VLAN for {label} released")
        except:
            log.info(f"VLAN for {label} not found")

        self.delete_managed_vlan_resource(resource_id)
        log.info(f"Deleting managed VLAN resource")

        self.delete_managed_policy_map_resource(resource_id)
        log.info(f"Deleting managed Policy Map resource")

        self.delete_managed_logical_port_resource(resource_id)
        log.info(f"Deleting managed Logical Port resource")

        self.delete_l2vpn_relationships(resource_id)
        log.info(f"Deleting Customer, Site and BandwidthProfile relationships")

        dependencies = self.bpo.resources.get_dependencies(resource_id)
        if dependencies:
            raise Exception(f"L2VPN has dependencies ({dependencies})")

        log.info(f"Terminate: DONE")
        return {}

    def delete_customer(self, resource_id):
        dependencies = self.bpo.resources.get_dependencies(resource_id)
        self.bpo.resources.delete_dependencies(
                            self.params['resourceId'], 
                            'training.resourceTypes.Customer',
                            dependencies)
 
    def delete_site(self, resource_id):
        dependencies = self.bpo.resources.get_dependencies(resource_id)
        self.bpo.resources.delete_dependencies(
                            self.params['resourceId'], 
                            'training.resourceTypes.Site',
                            dependencies) 
 
    def delete_bandwidthprofile(self, resource_id):
        dependencies = self.bpo.resources.get_dependencies(resource_id)
        self.bpo.resources.delete_dependencies(
                            self.params['resourceId'], 
                            'training.resourceTypes.BandwidthProfile',
                            dependencies)

    def delete_l2vpn_relationships(self, resource_id):
        self.bpo.relationships.delete_source_relationships(resource_id)

    def delete_managed_vlan_resource(self, resource_id):
        try:
            managed_vlan = self.bpo.resources.get_dependencies_with_filters(
                resource_id,
                ExactTypeId("radevsim.resourceTypes.Vlan")
            )[0]
            self.bpo.relationships.delete_source_relationships(managed_vlan['id'])
            self.bpo.relationships.delete_relationships(managed_vlan['id'])
            self.bpo.resources.delete(managed_vlan['id'])
            self.bpo.resources.await_termination(managed_vlan['id'], managed_vlan['label'], True)
            log.info("Managed VLAN deleted.")
        except Exception as e:
            raise Exception(f"Could not delete managed VLAN: {e}")

    def delete_managed_policy_map_resource(self, resource_id):
        try:
            managed_policy_map = self.bpo.resources.get_dependencies_with_filters(
                resource_id,
                ExactTypeId("radevsim.resourceTypes.PolicyMap")
            )[0]
            self.bpo.relationships.delete_source_relationships(managed_policy_map['id'])
            self.bpo.relationships.delete_relationships(managed_policy_map['id'])
            self.bpo.resources.delete(managed_policy_map['id'])
            self.bpo.resources.await_termination(managed_policy_map['id'], managed_policy_map['label'], True)
            log.info("Managed Policy Map deleted.")
        except Exception as e:
            raise Exception(f"Could not delete managed Policy Map: {e}")
    def delete_managed_logical_port_resource(self, resource_id):
        try:
            site_resource = self.bpo.resources.get_dependency_with_filters(resource_id, ExactTypeId("training.resourceTypes.Site"))
            port_resource = self.bpo.resources.get_dependency_with_filters(site_resource['id'], ExactTypeId("training.resourceTypes.Port"))
            managed_port_resource = PortUtils.get_managed_port_resource(self, port_resource['properties']['portName'], port_resource['properties']['deviceName'], port_resource['properties']['portSpeed'])
            managed_logical_port_resources = self.bpo.resources.get_dependencies_by_type(port_resource['id'], managed_port_resource['resourceTypeId'])
            managed_logical_port_resource = [port for port in managed_logical_port_resources if "." in port['label']][0]
            self.bpo.relationships.delete_source_relationships(managed_logical_port_resource['id'])
            self.bpo.relationships.delete_relationships(managed_logical_port_resource['id'])
            self.bpo.resources.delete(managed_logical_port_resource['id'])
            self.bpo.resources.await_termination(managed_logical_port_resource['id'], managed_logical_port_resource['label'], True)
            log.info("Managed Logical Port deleted.")
        except Exception as e:
            raise Exception(f"Could not delete managed Logical Port: {e}")

class Update(Plan):
    """
    Updates the VLAN parameter
    Updates the managed VLAN resource
    Updates the managed logical port resource
    """
    def run(self):
        log.info(f"Update: Input params: {self.params}")

        resource_id = self.params['resourceId']
        resource = self.bpo.resources.get(resource_id)

        log.info(f"Update: resourceId {resource_id}")
        log.info(f"Update: {resource}")

        label = resource['label']
        vlan_num_res = self.bpo.resources.get_one_by_filters(
                resource_type=POOL_NUMBER_RESOURCE_TYPE,
                q_params={"label": f"{label}.VLAN"}
        )

        Terminate.delete_managed_vlan_resource(self, resource_id)
        self.bpo.relationships.delete_relationships(vlan_num_res['id'])
        self.bpo.resources.delete(vlan_num_res['id'])
        log.info(f"VLAN for {label} released")

        allocated_vlan = Activate.allocate_vlan(self, resource)
        Activate.create_managed_vlan_resource(self, resource, allocated_vlan)

        Terminate.delete_managed_logical_port_resource(self, resource_id)
        Activate.create_managed_logical_port(self, resource, allocated_vlan)

        log.info(f"Update: DONE")
        return {}

class ChangePort(Plan):
    """
    Changes the Port and Device attached to selected Site in L2VPN resource
    Updates the managed VLAN resource
    Updates the managed logical port resource
    """
    def run(self):
        log.info(f"ChangePort: Input params: {self.params}")

        resource_id = self.params['resourceId']
        resource = self.bpo.resources.get(resource_id)

        log.info(f"ChangePort: resourceId {resource_id}")
        log.info(f"ChangePort: {resource}")

        operation = self.bpo.resources.get_operation(resource_id, self.params['operationId'])
        inputs = operation['inputs']

        log.info(f"ChangePort: inputs {inputs}")
        site_label = inputs['siteLabel']

        # Verify that the Site exists
        try:
            site_res = self.bpo.resources.get_one_by_filters(
                    resource_type="training.resourceTypes.Site",
                    q_params={"label": f"{site_label}"}
            )
            log.info(f"Site resource for {site_label} found.")
        except:
            raise Exception(f"Site resource for {site_label} not found.")

        # Find the Port resource attached to this Site
        try:
            port_res = self.bpo.resources.get_dependency_by_type(site_res['id'], "training.resourceTypes.Port")
            log.info(f"Port resource for {site_label} found - {port_res}")
        except:
            raise Exception(f"Port resource for {site_label} not found!")

        # Patch the Port resource
        self.bpo.resources.patch(port_res['id'], {
            "properties": {
                "portName": inputs['portName'],
                "deviceName": inputs['deviceName'],
                "portSpeed": inputs['portSpeed']
            }
        })
        log.info(f"Port resource for {site_label} patched.")

        # Patch the Site resource
        self.bpo.resources.patch(site_res['id'], {
            "properties": {
                "portName": inputs['portName'],
                "deviceName": inputs['deviceName'],
                "portSpeed": inputs['portSpeed']
            }
        })
        log.info(f"Site resource for {site_label} patched.")


        # Update relationship between port and managed port resources
        old_managed_port_resource = PortUtils.get_managed_port_resource(self, port_res['properties']['portName'], port_res['properties']['deviceName'], port_res['properties']['portSpeed'])
        self.bpo.relationships.delete_by_source_and_target(port_res['id'], old_managed_port_resource['id'])
        managed_port_resource = PortUtils.get_managed_port_resource(self, inputs['portName'], inputs['deviceName'], inputs['portSpeed'])
        self.bpo.relationships.add_relationship(port_res['id'], managed_port_resource['id'])

        # Update managed VLAN resource
        managed_vlan = self.bpo.resources.get_dependencies_with_filters(
            resource_id,
            ExactTypeId("radevsim.resourceTypes.Vlan")
        )[0]
        Terminate.delete_managed_vlan_resource(self, resource_id)
        Activate.create_managed_vlan_resource(self, resource, managed_vlan['properties']['id'])

        # Delete and re-create a managed logical port resource
        Terminate.delete_managed_logical_port_resource(self, resource_id)
        Activate.create_managed_logical_port(self, resource, managed_vlan['properties']['id'])

        log.info(f"ChangePort: DONE")
        return {}
