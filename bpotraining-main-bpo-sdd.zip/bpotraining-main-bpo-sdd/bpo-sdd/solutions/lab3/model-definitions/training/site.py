from plansdk.apis.plan import Plan
import logging

log = logging.getLogger(__name__)

class Activate(Plan):
    """
    Creates Site resource into market
    Creates Port resource into market
    """
    def run(self):
        log.info(f"Activate: Input params: {self.params}")

        resource_id = self.params['resourceId']
        resource = self.bpo.resources.get(resource_id)

        log.info(f"Activate: resourceId {resource_id}")
        log.info(f"Resource: {resource}")

        port = self.create_port(resource)
        log.info(f"Create Port resource: {port}")

        log.info("Activate: DONE")
        return {}

    def create_port(self, resource):
        properties = resource['properties']

        port_product = self.bpo.market.get_products_by_resource_type('training.resourceTypes.Port')[0]
        port = self.bpo.resources.create(self.params['resourceId'], {
            'productId': port_product['id'],
            'label': f"{resource['label']}.Port",
            'properties': {'deviceName': properties["deviceName"],
                           'portName': properties["portName"],
                            'portSpeed': properties["portSpeed"]}
        })
        return port

class Terminate(Plan):
    """
    Remove Site resource from market
    Remove dependent Port resources from market
    """
    def run(self):
        log.info(f"Terminate: Input params: {self.params}")

        resource_id = self.params['resourceId']
        resource = self.bpo.resources.get(resource_id)

        log.info(f"Terminate: resourceId {resource_id}")
        log.info(f"Resource: {resource}")

        self.delete_port(resource_id)
        log.info(f"Deleting Port dependencies for Site {resource['label']}")

        dependencies = self.bpo.resources.get_dependencies(resource_id)
        if dependencies:
            raise Exception(f"Site has dependencies ({dependencies})")

        log.info(f"Terminate: DONE")
        return {}

    def delete_port(self, resource_id):
        dependencies = self.bpo.resources.get_dependencies(resource_id)
        self.bpo.resources.delete_dependencies(
                            self.params['resourceId'],
                            'training.resourceTypes.Port',
                            dependencies)



