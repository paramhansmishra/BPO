from plansdk.apis.plan import Plan
import logging

log = logging.getLogger(__name__)

class Activate(Plan):
    """
    Creates BandwidthProfile resource into market
    """
    def run(self):
        log.info(f"Activate: Input params: {self.params}")

        resource_id = self.params['resourceId']
        resource = self.bpo.resources.get(resource_id)

        log.info(f"Activate: resourceId {resource_id}")
        log.info(f"Resource: {resource}")

        log.info("Activate: DONE")
        return {}

class Terminate(Plan):
    """
    Remove BandwidthProfile resource from market
    """
    def run(self):
        log.info(f"Terminate: Input params: {self.params}")

        resource_id = self.params['resourceId']
        resource = self.bpo.resources.get(resource_id)

        log.info(f"Terminate: resourceId {resource_id}")
        log.info(f"Resource: {resource}")

        dependencies = self.bpo.resources.get_dependencies(resource_id)
        if dependencies:
            raise Exception(f"BandwidthProfile has dependencies ({dependencies})")

        log.info(f"Terminate: DONE")
        return {}







